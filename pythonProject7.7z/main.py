from flask import Flask, render_template
from data.users import User
from data.jobs import Jobs
from data.db_session import create_session, global_init

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/")
def index():
    global_init(f"db/blogs.db")
    db_sess = create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template("index.html", jobs=jobs)


def main():
    app.run(port=8000)


if __name__ == '__main__':
    main()
